# Codex 接手入口｜PhotoAtelier V2.5

先阅读：

1. `START-HERE-V2.5-IMPLEMENTATION.md`
2. `IMPLEMENTATION-REPORT-V2.5.md`
3. `EXTERNAL-INTEGRATION-TASKS-V2.5.md`
4. `TEST-REPORT-V2.5.md`
5. `architecture/07-ACCEPTANCE-TEST-MATRIX.md`

然后执行：

```bash
npm ci
npm run test:release
npm run test:e2e
```

## 当前基线

- V2.5 领域层已实现。
- 开发目录发布门禁 68 / 68 Node／集成测试通过。
- 现有 UI 尚未完全迁移到 V5 Use Cases，不能借机重做 UI。
- 真实外部账号与模型验收见 `EXTERNAL-INTEGRATION-TASKS-V2.5.md`。

## 第一优先级

1. 在正常浏览器环境复跑 E2E。
2. 使用真实账号验证飞书、Obsidian、Pexels 和 AI Provider。
3. 逐页把旧 DataService 编排替换为 `context.v5` Use Cases。
4. 保持所有 V5 合同和 68 项测试不回归。

## 禁止

- 不得重新设计领域模型或字段。
- 不得把型号目录当成用户拥有设备。
- 不得将 AI 图片写成真实参考图。
- 不得把预计收入当作已收。
- 不得把 SharePacket 替换为完整方案副本。
- 不得在 UI 页面中新增跨实体写入编排。
- 不得声称 Mock 服务等于真实集成通过。
