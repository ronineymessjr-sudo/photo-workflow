# PhotoAtelier V2.3 测试报告

日期：2026-07-15

## 已通过

### 完整发布门禁

```bash
npm run test:release
```

结果：通过。

### Node 与集成测试

结果：38/38 通过。

覆盖：

- Agent 草稿、审批和幂等。
- 旧数据迁移、备份、恢复和完整性审计。
- LUT 解析、采样、重采样和许可目录。
- Obsidian 索引与回链。
- 项目模板。
- 日程冲突。
- 开拍就绪门禁。
- 模特授权。
- 摄影师、模特、助理和客户角色摘要。
- 内部通告与脱敏角色包。
- 助理清单幂等。
- 镜头设置切换。
- 多角色反馈分析。
- 四角色完整项目场景。

### 静态与发布

- 语法检查：通过。
- Smoke：通过。
- V2 构建：通过。
- 发布包检查：通过。
- 安全扫描：32 个公开文件通过。
- npm audit：0 个已知依赖漏洞。
- 正式发布包：约 289 KiB，低于 2MB 预算。
- Classic 可选包：约 18MB。

## 未通过或无法执行

### 浏览器 E2E

命令：

```bash
npm run test:e2e
```

当前沙箱结果：

```text
page.goto: net::ERR_BLOCKED_BY_ADMINISTRATOR
http://127.0.0.1:8123/
```

本地服务器可由非浏览器请求访问，因此这是当前 Chromium 沙箱导航策略限制。不能把它记录为产品测试通过，也没有降低断言绕过。

## Codex 或本机必须继续验证

1. 正常 Chrome/Chromium 运行 `npm run test:e2e`。
2. 手机安装 PWA 后执行断网恢复。
3. 飞书测试 Base 的同步、冲突和删除墓碑。
4. Obsidian 测试 Vault 的 Search、Read、Write。
5. Cloudflare Pages 部署 `dist-v2`，确认 Classic 占位页和缓存更新。
6. 需要 Classic 时，将 `dist-classic-addon` 覆盖到同一发布根目录并单独验证。
