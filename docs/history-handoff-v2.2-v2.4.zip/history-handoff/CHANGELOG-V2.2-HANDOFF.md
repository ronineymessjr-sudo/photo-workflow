> **当前版本提示（2026-07-15）**：正式交接版本为 V2.3。请先阅读 `START-HERE-CODEX-2026-07-15.md`、`ITERATION-REPORT-V2.3.md`、`MARKET-RESEARCH-V2.3.md` 与 `TEST-REPORT-V2.3.md`。下方内容保留为历史背景。

# V2.2 Handoff 变更记录

## 架构

- 根路径改为模块化 V2 正式入口。
- Classic 移至历史对照定位。
- 新增统一实体、版本和三维状态模型。
- 旧 Supabase/JWT Worker 移入 `legacy/cloud-api/`。

## 数据

- 重写 StorageRepository 和 DataService。
- 新增完整备份、合并/替换恢复、失败回滚。
- 扩展 Classic 数据迁移范围并保证幂等。
- 新增重复 ID、孤立项目和孤立方案审计。

## 产品流程

- Agent 草稿 → 预选 → 正式确认 → 排期。
- 月历、shoot-call 和现场镜头状态。
- ShootRecord 与拍摄自动完成。
- 后期双备份、选片、版本、反馈和交付状态。
- 复盘 Markdown 与 Obsidian 回流。

## LUT

- 新增 ESM `.cube` 解析器。
- 三线性 LUT 采样。
- 原始/输出/目标三栏 Canvas 预览。

## 集成

- 修正 Worker 与本地 Obsidian Bridge 的搜索和读取协议。
- 扩展飞书字段映射。
- CI 改为质量门禁后分别部署 Pages 与 Worker。

## 测试

- 新增 V2 Handoff Node 测试。
- 浏览器可执行文件跨平台发现。
- V2 E2E 扩展为完整摄影主流程。
