> **当前版本提示（2026-07-15）**：正式交接版本为 V2.3。请先阅读 `START-HERE-CODEX-2026-07-15.md`、`ITERATION-REPORT-V2.3.md`、`MARKET-RESEARCH-V2.3.md` 与 `TEST-REPORT-V2.3.md`。下方内容保留为历史背景。

# PhotoAtelier 项目完整交接说明

> 用途：把本文件连同必要源码交给 ChatGPT，让它在不了解此前对话的情况下，能够理解 PhotoAtelier 的目标、现状、数据、模块关系、外部项目、风险和后续改造方向。
>
> 文档生成日期：2026-07-10
>
> 当前主项目候选目录：`C:\Users\user\Documents\trae-soio\photo-workflow`
>
> 重要说明：本文不包含任何 API Key、App Secret、JWT Secret、Cookie 或登录凭证。

---

## 0. 给 ChatGPT 的任务说明

请先完整阅读本文，再阅读项目源码。不要立即重写项目，也不要只提出表面 UI 建议。需要从产品、数据、架构、摄影工作流、来源授权、可维护性和迁移风险多个角度完成梳理。

请重点回答：

1. 当前产品的准确定位和核心用户工作流是什么？
2. 哪些现有功能应该保留、合并、重构、冻结或删除？
3. 浏览器、Node 本地服务、Obsidian、图片文件夹、外部图库、Cloudflare 和 Supabase 各自应该拥有什么数据？
4. 现有数据是否足以支撑推荐、语义搜索和 Agent？还缺什么数据与评测集？
5. 本文列出的外部项目是否真的适合接入？应该接在哪里，调用方式和退出机制是什么？
6. 如何在不丢失现有方案、日程、设置和 Obsidian 笔记的情况下逐步迁移？
7. 请形成可以由 Codex 分阶段实施的明确反馈，不要只输出概念性建议。

请在最后严格按照本文末尾的“反馈模板”输出结论，方便把反馈交回 Codex 实施。

---

## 1. 项目一句话定义

PhotoAtelier 是一个面向个人摄影师的、免登录、本地优先的摄影生产工作台。

它希望把以下环节连接成一个可以追踪、复用和持续学习的闭环：

```text
素材收藏与本地图库
  -> 主题和 Brief
  -> 参考素材、角度、姿势、构图、光线和 LUT 匹配
  -> 拍摄方案与镜头清单
  -> 日程和现场执行
  -> 选片、调色和交付
  -> 国内外发布包
  -> 拍摄复盘
  -> 经验及优质成片回流到知识库
```

项目不应继续只是“输入几个字段后生成一份长文本”，也不应在当前阶段扩展成多人 SaaS、影楼 ERP 或公开素材下载站。

---

## 2. 用户目标与约束

### 2.1 核心目标

- 测试和日常使用无需登录。
- 优先使用本机 Obsidian、图片文件夹和现有收藏数据。
- 能根据主题找到真实参考素材，而不是只生成描述。
- 推荐要能解释来源、用途、匹配理由、授权和置信度。
- 方案必须落到可执行镜头，而不是只有审美形容词。
- 支持 LUT 管理、参考仿色和颜色流程说明。
- 支持小红书、抖音、朋友圈及海外平台的发布准备。
- 拍摄结果和复盘能够反向改善下一次推荐。
- 外部项目必须经过维护状态、许可证、数据规模、专业性、调用方式和社区反馈审查后才能接入。

### 2.2 默认约束

- 本地个人工作台优先，云同步是可选能力。
- 原图不能塞进浏览器数据库。
- 不能修改或覆盖用户原始照片。
- 不能静默改写用户原有 Obsidian 笔记。
- 平台收藏导入依赖用户正常登录，不绕过平台限制。
- 单个外部来源失败不能阻断方案生成。
- 现有浏览器数据、方案、日程和设置必须无损保留。
- 先渐进拆分，不整体推倒重写。

### 2.3 暂不进入核心范围

- 多人组织与权限体系。
- 公开 SaaS 注册、收费和订阅。
- 客户合同、支付、发票和完整 CRM。
- 自动发布到所有社交平台。
- 自动下载用户所有平台收藏的绕过风控方案。
- 改变人物、构图和内容的生成式风格迁移。

---

## 3. 本地位置与历史副本

### 3.1 当前项目

```text
C:\Users\user\Documents\trae-soio\photo-workflow
```

这是当前实际开发和运行的版本，应作为后续主仓库候选。

### 3.2 Obsidian Vault

```text
C:\Users\user\Documents\Obsidian Vault
```

与摄影相关的主要目录：

```text
摄影姿势库/
  00_姿势库总览.md
  00_小红书收藏_拍摄专辑.md
  00_小红书收藏_设计专辑.md
  00_小红书收藏_视频拍摄专辑.md
  00_小红书收藏_调色专辑.md
  小红书笔记/
  拍摄指南/
  姿势示意图/
  汉服/
```

当前已确认至少包含摄影 Markdown 笔记、姿势说明和本地示例图片。Obsidian 应作为知识和经验层，而不是运行时业务数据库。

### 3.3 旧副本

```text
D:\AI工具\photo-workflow
```

这是较旧的静态页面版本。虽然旧 Obsidian 项目说明曾把它描述为 Tauri 版本，但实际检查没有发现 `src-tauri`、`tauri.conf.json` 或当前可用的 Tauri 工程结构。

建议：

- 不直接合并回当前项目。
- 标记为只读历史副本。
- 只在需要追溯旧功能或旧 UI 时做差异参考。

### 3.4 敏感配置

工作区上层存在 `PhotoAtelier-Config.md`，其中曾保存云端和飞书相关敏感配置。

- 不要把该文件上传给 ChatGPT。
- 不要在分析报告中复述其中的值。
- 后续实施前应轮换敏感密钥，并将秘密迁入本地环境文件、系统凭据存储或部署平台 Secret。

---

## 4. 当前实际运行架构

当前项目并不是 README 中描述的单一 Cloudflare 架构，而是四套系统叠加：

```mermaid
flowchart LR
    UI["单页前端 index.html"] --> LS["localStorage"]
    UI --> IDB["IndexedDB"]
    UI --> LOCAL["Node 本地代理 127.0.0.1:8124"]
    UI -.可选.-> CLOUD["Cloudflare Worker"]
    CLOUD -.可选.-> SUPA["Supabase"]
    LOCAL --> VAULT["Obsidian Vault"]
    LOCAL --> JSON["本地 JSON 数据库"]
```

### 4.1 前端

- 主文件：`index.html`
- 规模：约 13,600 行、720 KB。
- 技术：Vanilla HTML/CSS/JavaScript。
- 静态服务器：`python -m http.server 8123 --directory .`
- 本地地址：`http://127.0.0.1:8123/`
- localhost 默认进入本地测试会话，不要求登录。
- 页面仍使用大量全局函数、内联事件和直接 `localStorage` 访问。
- jsPDF、Motion、Lucide 当前通过 CDN 加载。

### 4.2 新增领域模块

```text
src/domain.js
src/storage.js
src/app-enhancements.js
src/enhancements.css
```

职责现状：

- `domain.js`：实体类型、Brief 标准化、关系、去重、LUT 解析、发布包、工作流评估。
- `storage.js`：IndexedDB 对象仓库和 legacy localStorage 迁移。
- `app-enhancements.js`：方案生命周期、日程、现场记录、复盘、LUT、发布包、候选素材、备份恢复等 UI 增强。
- `enhancements.css`：增强区域样式。

问题：这些文件已经开始拆分，但仍高度依赖 `index.html` 中的 DOM ID、全局函数和旧存储键，还没有形成真正独立的模块边界。

### 4.3 本地 Node 服务

文件：`tools/local-obsidian-proxy.js`

默认地址：

```text
http://127.0.0.1:8124
```

现有接口：

| 接口 | 方法 | 当前用途 |
|---|---|---|
| `/v1/health` | GET | Vault、索引和文件数量健康检查 |
| `/v1/index/rebuild` | POST | 重建 Markdown、附件和图片索引 |
| `/v1/search` | GET | 文本、标签、类型、方向等查询 |
| `/v1/assets/:id/thumbnail` | GET | 返回白名单目录内缩略图 |
| `/v1/notes` | POST | 向 PhotoAtelier 专用目录写入复盘笔记 |
| `/v1/candidates/run` | POST | 生成每日候选素材 |
| `/v1/candidates` | GET | 获取候选列表 |

当前服务同时承担文件扫描、Markdown 解析、EXIF 子集读取、搜索、候选生成和笔记写入。后续应拆成控制器、索引器、Repository、任务服务和连接器。

### 4.4 云端后端

```text
api/index.js
wrangler.toml
DEPLOYMENT.md
```

云端后端包含登录、方案、日程、消息和统计 API，使用 Cloudflare Worker 和 Supabase REST。

但当前默认产品方向是免登录、本地优先，因此云端后端不应继续作为默认主链路。建议先冻结为可选同步层，待本地数据模型稳定后再重新设计同步协议。

### 4.5 旧 README 状态

现有 `README.md` 仍将产品描述为 Cloudflare + Supabase 应用，也继续包含已不准确的功能和目录说明。它不能作为当前架构真相，应在最终架构确定后重写。

---

## 5. 当前界面与信息架构

主侧边栏目标固定为六项：

1. 方案
2. 素材库
3. 日程
4. 消息
5. 历史
6. 设置

### 5.1 方案

目标流程：

```text
Brief
  -> 推荐关系
  -> 镜头执行
  -> LUT/调色
  -> 国内外发布
```

场地、模特和设备应作为方案中的资源抽屉或关联实体存在，不应重新增加独立侧边栏页面。

### 5.2 素材库

需要统一显示：

- 本地图片和视频。
- Obsidian 笔记中的附件和链接。
- 小红书、抖音收藏导入。
- Pexels、Unsplash、Pixabay 等外部搜索结果。
- 素材来源、作者、授权、质量和验证状态。
- 素材在方案中的用途和关联镜头。

### 5.3 日程

建议状态：

```text
准备中 -> 待拍摄 -> 拍摄中 -> 待选片 -> 待交付 -> 已完成
```

日程必须保留 `planId`、`topicId`、关联镜头和外部日历 ID。

### 5.4 消息

消息页应成为统一 Inbox，而不是演示消息列表。它承载：

- 导入失败。
- 待验证素材。
- 日程提醒。
- 缺失推荐槽位。
- 每日检索候选。
- 外部服务降级和任务失败。

### 5.5 历史

需要支持：

- 方案版本比较。
- 恢复历史版本。
- 复制为新方案。
- 查看关联日程和复盘。
- 追踪素材替换和锁定记录。

### 5.6 设置

集中管理：

- Obsidian Vault 和连接状态。
- 本地图库目录。
- 可选 DAM 服务。
- 平台收藏源。
- 外部图库 API。
- 每日任务。
- 数据备份恢复。
- 飞书同步。
- 云同步开关。
- 连接健康和索引版本。

---

## 6. 当前数据资产

### 6.1 参考数据库

文件：`assets/reference-database.json`

当前统计：

| 项目 | 数量 |
|---|---:|
| 总记录 | 262 |
| 有来源 URL | 131 |
| 有 sourceFile | 254 |
| 有作者 | 47 |
| 本地素材记录 | 25 |
| 有统一 validationStatus | 0 |

主要分类：

| 分类 | 数量 |
|---|---:|
| 姿势/引导 | 116 |
| 综合参考 | 62 |
| 国风/汉服 | 43 |
| 构图/技巧 | 19 |
| 视频拍摄 | 9 |
| 调色/后期 | 5 |
| 其他外部来源 | 少量 |

结论：

- 足以验证分类、关系图谱和界面。
- 不足以证明推荐质量。
- 很多记录只是笔记或链接，不是真正可检索的本地视觉素材。
- 需要补作者、作品 ID、规范 URL、许可证、验证状态、哈希和真实文件定位。

### 6.2 工作流数据库

文件：`assets/workflow-database.json`

当前统计：

| 数据 | 数量 |
|---|---:|
| 主题 | 12 |
| 文案方向 | 36 |
| 调色/LUT 方向 | 8 |
| 拍摄前检查模板 | 12 |
| 复盘模板 | 12 |

主题包括城市夜景、毕业照、新中式旗袍、咖啡馆日常、情侣城市故事、海边日落、室内情绪窗光、运动动态、品牌编辑、婚礼纪实等。

### 6.3 平台收藏配置

文件：`assets/platform-collections.json`

- 小红书已配置部分收藏夹。
- 抖音收藏源仍不完整。
- 当前采集器使用持久浏览器配置和页面 DOM 选择器，容易受到平台页面改版影响。

### 6.4 浏览器数据

目前存在两类主要键：

- `pw_*`：旧方案、日程、消息、角色和资源数据。
- `pa_*`：新工作流、镜头状态、LUT、设置、复盘和关系决策。

已知风险：

- `pw_schedule` 与 `pw_schedules` 曾同时存在。
- 业务数据同时写入 localStorage 和 IndexedDB。
- 部分镜头数据按 `pa_shots_<planId>` 等动态键分散存储。
- 云端加载可能再次和本地数据合并。

---

## 7. 建议统一数据模型

### 7.1 核心实体

```text
Asset
AssetVariant
Source
Collection
Note
Topic
Brief
Plan
Shot
StyleProfile
LutProfile
Schedule
ShootRecord
Review
PublishPackage
Relation
WorkflowRun
InboxItem
```

### 7.2 Relation

统一关系建议包含：

```json
{
  "id": "relation-id",
  "sourceId": "entity-id",
  "targetId": "entity-id",
  "role": "poseGuide",
  "score": 82,
  "reason": "匹配夜景人物和低机位全身镜头",
  "provenance": {
    "source": "obsidian",
    "sourceUrl": "",
    "licenseClass": "local-private-reference"
  },
  "validationStatus": "verified",
  "locked": false,
  "rejected": false,
  "updatedAt": "ISO-8601"
}
```

### 7.3 推荐槽位

```text
materialReference  素材参考
shotAngle          拍摄角度和景别
poseGuide          姿势与现场口令
composition        构图
lighting           光线
colorLut           LUT 与调色
publishingCopy     发布与平台文案
```

一条素材可以服务多个槽位，但每个关系必须说明它在当前方案中承担什么角色。

### 7.4 素材最低字段

```text
id
title
mediaType
sourceType
sourceUrl
sourceFile
platform
platformItemId
author
collectionId
licenseClass
commercialUse
attributionRequired
capturedAt
importedAt
width / height / orientation
camera / lens / focalLength / exposure / ISO
contentHash
perceptualHash
thumbnailPath
tags
workflowStage
validationStatus
```

### 7.5 数据真源建议

| 数据 | 建议真源 |
|---|---|
| 方案、镜头、关系、日程、复盘、Inbox | 本地 SQLite |
| 摄影知识、教程、经验笔记 | Obsidian |
| 原图、视频、RAW、LUT 文件 | 本地文件夹或独立 DAM |
| 浏览器 IndexedDB | UI 缓存和离线快照 |
| JSON | 种子、导入导出、备份 |
| Cloudflare/Supabase | 可选多设备同步，不是默认真源 |

---

## 8. 目标技术架构

```mermaid
flowchart LR
    WEB["PhotoAtelier Web UI"] --> API["Local Service API"]
    API --> SQLITE["SQLite + FTS"]
    API --> JOBS["索引与任务队列"]
    JOBS --> OBS["Obsidian Connector"]
    JOBS --> FILES["Local Media Connector"]
    JOBS --> DAM["Optional DAM Connector"]
    API --> EXIF["ExifTool Processor"]
    API --> COLOR["OpenColorIO Processor"]
    API --> PROVIDERS["External Provider Adapters"]
    PROVIDERS --> STOCK["Stock Libraries"]
    PROVIDERS --> SOCIAL["Platform Assisted Imports"]
    API -.optional sync.-> SYNC["Cloud Sync Gateway"]
```

### 8.1 推荐目录

```text
apps/
  web/                    浏览器界面
  local-service/          本地 API、SQLite、索引和任务
  desktop/                未来可选 Tauri 外壳

packages/
  domain/                 实体、关系、规则和迁移
  repositories/           数据访问接口
  workflows/              Brief、检索、方案、复盘 DAG
  connectors/
    obsidian/
    local-media/
    immich/
    feishu/
    xiaohongshu/
    douyin/
    pexels/
    unsplash/
    pixabay/
  processors/
    metadata/
    thumbnail/
    hashing/
    color/
    publishing/

data/
  seeds/                  主题、平台规格、文案、LUT 元数据

runtime/                  SQLite、索引、缓存、任务日志，禁止提交
legacy/
  cloud-sync/             冻结的 Worker/Supabase 代码
```

第一阶段不建议为了拆分而立即重写 React。可以保留现有 Vanilla JS，引入 ES Modules 和构建工具后按页面迁移。等领域和数据边界稳定后，再决定是否引入框架。

---

## 9. 主工作流设计

### 9.1 Brief 标准化

输入需要标准化为：

```text
主题
人物
场景
情绪
风格
用途
发布平台
预算
时长
设备限制
地点和时间限制
其他约束
```

### 9.2 检索

并行检索：

- Obsidian 知识。
- 本地图片和视频。
- 已导入平台收藏。
- 角度和景别。
- 姿势与动作口令。
- 构图。
- 光线。
- LUT/调色。
- 发布文案和关键词。

### 9.3 排序与验证

建议排序信号：

```text
主题与语义匹配
工作流槽位匹配
场景和人物匹配
视觉相似度
素材质量
来源完整度
授权安全
用户历史采用结果
更新时间
```

硬性规则：

- 商业用途下，来源和授权不明确的素材不能标记为可商用。
- 待验证素材可以展示，但不能伪装成高置信度正式推荐。
- 用户锁定的推荐不被自动替换。
- 用户否决的推荐进入负反馈记录。

### 9.4 方案编排

每个镜头至少需要：

```text
镜头目标
参考素材
机位
景别
焦段
构图
人物动作
摄影师口令
光线
相机建议
LUT/色彩方向
替代镜头
预计耗时
风险和补拍条件
```

### 9.5 现场与复盘

现场记录：

- 镜头完成勾选。
- 实拍备注。
- 样片路径。
- 失败原因。
- 补拍标记。
- 实际耗时。

复盘记录：

- 有效姿势和无效动作。
- 光线问题。
- 最终调色。
- 成片保留率。
- 客户反馈。
- 发布表现。
- 可复用经验。

优质复盘只能写入 PhotoAtelier 管理的 Obsidian 目录，不覆盖原笔记。

---

## 10. Agent 工作流

现有 `assets/agent-workflow.json` 定义了一个本地优先的顺序工作流：

```text
brief -> retrieve -> compose -> lut -> publish -> evaluate
```

建议继续使用确定性 DAG，不立即引入大型 Agent 框架。

每个步骤统一传递：

```text
workflowId
stepId
task
constraints
upstreamArtifacts
timeout
confidence
status
error
```

质量门检查：

- Brief 是否完整。
- 六到七个推荐槽位是否齐全。
- 素材是否真实存在。
- 来源和授权是否完整。
- 镜头是否可执行。
- 是否存在重复素材。
- 平台输出是否满足规格。
- 外部失败时是否已回退本地库。

每日检索只生成候选 InboxItem，不自动写入正式素材库。

---

## 11. 外部项目审查与接入位置

### 11.1 Obsidian Local REST API with MCP

- 官方项目：<https://github.com/coddingtonbear/obsidian-local-rest-api>
- 许可证：MIT。
- 状态：持续发布，提供 REST、MCP、搜索、文件打开、局部 PATCH 和命令执行。
- 接入位置：`packages/connectors/obsidian`。
- 用途：Obsidian 正在运行时打开、搜索和局部修改笔记。
- 保留现有文件扫描器：用于 Obsidian 未运行时的离线索引和附件处理。
- 不应让插件直接拥有方案、日程和复盘数据库。

### 11.2 ExifTool

- 官方文档：<https://exiftool.org/exiftool_pod2.html>
- 用途：读取图片、RAW、视频的 EXIF/IPTC/XMP/ICC 信息。
- 接入位置：`packages/processors/metadata`，由本地服务作为外部进程调用。
- 默认模式：只读。
- 写入模式：优先生成 XMP sidecar；不覆盖原图。
- 输出：规范 JSON，不把 ExifTool 原始字段直接泄漏到 UI。

### 11.3 IPTC/XMP

- 官方标准：<https://www.iptc.org/std/photometadata/specification/IPTC-PhotoMetadata-2025.1.html>
- 专业性：IPTC 标准委员会维护，适合作者、描述、版权、关键词、授权和 AI 来源信息。
- 接入位置：`packages/domain/asset-metadata`。
- 技术 EXIF 仍由 ExifTool 读取；IPTC 不替代相机技术元数据。

### 11.4 Immich

- 官方外部图库：<https://docs.immich.app/features/libraries/>
- 官方 API：<https://api.immich.app/endpoints>
- 特点：外部图库、缩略图、EXIF、相册、人物和 CLIP 智能搜索。
- 许可证：AGPL；建议独立部署，通过 API 调用，不复制其代码。
- 接入位置：`packages/connectors/immich`。
- 使用方式：把用户图库以只读目录挂载，PhotoAtelier 保存 Immich asset ID 和原路径。
- 限制：文件移动后，Immich 内部附加元数据可能失去关联，因此它不能是项目唯一真源。
- 决策：素材规模显著增长后作为可选 DAM Provider，不作为 P0/P1 强依赖。

### 11.5 digiKam

- 官方数据库说明：<https://docs.digikam.org/en/getting_started/database_intro.html>
- 特点：标签、评分、颜色标签、EXIF/IPTC/XMP、缩略图、相似度指纹和人脸数据库。
- 接入方式：不复制代码，不读取其内部数据库作为固定协议。
- 接入位置：通过 XMP sidecar 与 PhotoAtelier 互操作。
- 用途：作为用户人工整理图库的成熟 DAM，以及筛选器和元数据设计参考。

### 11.6 PhotoPrism

- 官方 API：<https://docs.photoprism.app/developer-guide/api/>
- 特点：图库索引、元数据搜索、缩略图和 AI 标签。
- 风险：官方说明 REST API 尚无正式弃用保障。
- 决策：不和 Immich 同时建设；只有用户已经使用 PhotoPrism 时再提供 Provider。

### 11.7 OpenColorIO

- 官方项目：<https://github.com/AcademySoftwareFoundation/OpenColorIO>
- 官方使用说明：<https://opencolorio.readthedocs.io/en/stable/guides/using_ocio/using_ocio.html>
- 许可证：BSD-3-Clause。
- 专业性：Academy Software Foundation 治理，支持 ACES、多种 LUT 和 CPU/GPU 处理。
- 接入位置：`packages/processors/color`。
- 用途：颜色空间转换、LUT 校验、派生预览和最终导出。
- 浏览器现有 `.cube` 解析器只保留为低分辨率即时预览。

### 11.8 sqlite-vec 与 OpenCLIP

- sqlite-vec：<https://github.com/asg017/sqlite-vec>
- OpenCLIP：<https://github.com/mlfoundations/open_clip>
- 用途：图片和自然语言向量检索。
- 接入位置：`apps/local-service/search/vector`。
- 风险：sqlite-vec 仍处于早期版本；OpenCLIP 引入 Python、模型文件和较大计算开销。
- 决策：先用 SQLite FTS、标签和结构化过滤。素材超过约 1,000 张且有人工评测集后，再以可关闭插件启用向量检索。
- 必须保留关键词检索降级路径。

### 11.9 Tauri 2

- 文件系统：<https://v2.tauri.app/reference/javascript/fs/>
- Sidecar：<https://tauri.app/develop/sidecar/>
- 接入位置：未来 `apps/desktop`。
- 用途：统一启动 Web UI、本地服务、ExifTool/OpenColorIO sidecar，并使用系统文件选择器和路径权限。
- 决策：等本地 API 和模块稳定后再包装。不要从 D 盘旧副本“合并 Tauri”。

### 11.10 Agent 框架

当前不建议接入 LangGraph 等框架。

原因：

- 当前主要是确定性本地工作流。
- 尚未建立稳定的模型调用、任务持久化和质量评测。
- 引入框架不能自动解决素材真实性、授权、关系评分和数据缺失问题。

达到以下条件再评估：

- 多模型并行调用已成为真实需求。
- 工作流需要跨重启恢复。
- 人工审核节点和重试明显增多。
- 已有可量化的 Agent 评测集。

---

## 12. 外部素材平台规则

### 12.1 Pexels

- 官方 API：<https://www.pexels.com/api/documentation/>
- 可作为第一批正式在线搜索 Provider。
- 必须显示作者和 Pexels 来源。
- 默认额度有限，需要缓存搜索和追踪剩余额度。
- 结果进入素材库前保留 Pexels ID、作者、原页面、图片尺寸和许可证快照。

### 12.2 Unsplash

- 官方 API：<https://unsplash.com/documentation>
- 必须热链官方图片 URL、署名作者和 Unsplash。
- 用户选择素材时需要调用 download tracking endpoint。
- Secret Key 不能放在浏览器端。
- 默认作为在线搜索和链接引用，不直接建立永久本地镜像。

### 12.3 Pixabay

- 官方 API：<https://pixabay.com/api/docs/>
- 搜索请求需缓存 24 小时。
- 不允许系统化批量下载。
- 图片 URL 只适合临时展示；正式使用时按规则下载到用户素材目录并记录来源。

### 12.4 小红书与抖音

- 采用用户已登录浏览器辅助导入。
- 每次采集保存原始页面快照、解析结果、采集时间和失败信息。
- 解析器按平台单独隔离，页面改版不影响本地图库和方案功能。
- 支持手工 URL 和 CSV 兜底。
- 抓取到的内容先进入待验证队列。
- 不设计绕过登录、验证码、签名或平台风控的方案。

### 12.5 Provider 统一接口

```text
health()
search(query, filters, cursor)
getAsset(externalId)
getThumbnail(externalId)
getLicenseSnapshot(externalId)
importReference(externalId, mode)
```

统一结果必须包含：

```text
provider
externalId
title
author
sourceUrl
previewUrl
downloadMode
attribution
licenseClass
commercialUse
fetchedAt
rawPayloadRef
```

---

## 13. LUT 与颜色工具

### 13.1 第一阶段

建立 LUT 档案，而不是直接收集大量来源不明的 `.cube` 文件。

字段：

```text
名称
文件路径
来源
作者
许可证
适用相机
输入颜色空间
LUT 预期输入
输出颜色空间
肤色表现
适用场景
不适用场景
强度建议
验证样片
```

### 13.2 预览

```text
原图
LUT 预览
参考仿色
```

- 浏览器负责小图快速预览。
- OpenColorIO 负责正式、可验证的转换。
- 所有结果生成新文件或缓存预览，不覆盖原图。

### 13.3 仿色边界

第一版只做：

- 白平衡倾向。
- 明暗曲线。
- 主色和辅色。
- 饱和度。
- 对比度。
- 肤色倾向。
- 最接近 LUT 与参数组合。

不自动改变人物、动作、构图或画面内容。

---

## 14. 发布与 SEO

当前项目容易把“平台关键词”和“网站 SEO”混为一谈，建议拆成两个实体。

### 14.1 SocialPublishPackage

面向：

```text
小红书
抖音
朋友圈
Instagram
Pinterest
TikTok
YouTube Shorts
```

包含：

- 平台比例和时长。
- 封面安全区。
- 标题候选。
- 正文结构。
- 封面字。
- 标签。
- 发布时间建议。
- 中文和英文关键词。
- 平台特定素材选择。

### 14.2 WebSeoPackage

面向作品网站和可被搜索引擎访问的页面：

- 页面标题和描述。
- Alt Text。
- `ImageObject` JSON-LD。
- 作者、版权和许可证。
- IPTC 元数据。
- 图片 Sitemap。
- Open Graph 图片。
- 响应式图片和 WebP/AVIF 派生版本。

Google 图片 SEO 官方说明：<https://developers.google.com/search/docs/appearance/google-images>

本地工作台本身不需要被 Google 索引；只有用户导出或发布的网站页面才需要 Web SEO。

---

## 15. 飞书和外部协作

现有项目曾提供飞书日历和多维表格同步。

建议定位：

- PhotoAtelier SQLite 是主数据。
- 飞书日历是外部日程镜像。
- 飞书多维表格是分享、备注、审核或运营视图。
- 每条同步记录保存 `externalId`、`lastSyncedAt`、`syncStatus` 和冲突信息。
- 同步必须幂等，不能重复创建事件或记录。
- 飞书 App Secret 只能由本地服务或部署 Secret 使用，不能出现在前端或 README。

---

## 16. 数据是否足够

### 16.1 当前可以做的

- 建立统一分类和关系图谱。
- 验证本地搜索、来源展示和授权状态。
- 做 12 个主题的规则型方案推荐。
- 建立 LUT 档案和少量真实样片测试。
- 验证方案、日程、现场、复盘闭环。

### 16.2 当前不能证明的

- 推荐结果对不同摄影主题稳定有效。
- 语义搜索比标签搜索明显更好。
- 自动构图或镜头分类达到专业可用水平。
- LUT 匹配在不同相机和颜色空间下可靠。
- 平台文案能够提高真实发布表现。

### 16.3 建议数据门槛

这些不是行业硬标准，而是项目启用下一阶段能力的内部触发条件：

- 先补到至少 500 条来源和用途明确的验证素材。
- 每个主要主题至少覆盖素材、角度、姿势、构图、光线和颜色槽位。
- 建立至少 50 个真实 Brief 的检索评测集。
- 每个 Brief 对 Top 10 结果做相关/不相关人工判断。
- 累积至少 30 次真实拍摄复盘后再调整采用率权重。
- 本地视觉素材接近或超过 1,000 张时，再评估 OpenCLIP 向量检索的实际收益。

预训练 CLIP 不需要用用户图片重新训练，但项目仍需要自己的人工评测集来证明检索质量。

---

## 17. 主要风险

### P0 风险

- 工作区存在明文敏感配置，需要轮换。
- 当前大量新增文件未被 Git 跟踪，尚无可靠恢复基线。
- C 盘当前项目、D 盘旧副本和旧文档描述不一致。
- README、部署文档与本地主链路不一致。

### P1 风险

- `index.html` 体积过大，函数和 DOM 关系难以追踪。
- localStorage、IndexedDB 和云端可能出现多份真源。
- 动态存储键可能导致迁移遗漏。
- 旧全局函数和新模块可能重复响应同一事件。

### P2 风险

- 平台页面导入容易因 DOM 改版失效。
- 来源不完整的收藏存在版权和真实性风险。
- EXIF、RAW、HEIC、视频缩略图需要跨格式处理。
- Immich、PhotoPrism 等 DAM 的内部元数据不能直接当作永久标准。

### P3 风险

- 推荐“看起来合理”不等于摄影现场可执行。
- 用户反馈量少时，自动学习容易过拟合。
- 模型和向量数据库会增加安装体积、运行时间和维护成本。
- LUT 若缺少颜色空间定义，预览结果可能具有误导性。

---

## 18. 分阶段实施建议

### P0：基线、安全和主项目确认

目标：保证任何后续改造都可恢复。

- 确认 C 盘当前目录为唯一主仓库。
- 给 D 盘旧副本增加归档说明。
- 备份 localStorage、IndexedDB、Obsidian 配置和 JSON 数据。
- 建立当前源码基线提交。
- 轮换并移除明文秘密。
- 清理 `.browser-profile`、debug HTML、截图和运行缓存的项目污染。
- 更新项目状态文档，但暂不改变业务行为。

验收：现有数据和页面行为与改造前一致，且能一键恢复。

### P1：统一数据底座

目标：只有一个业务数据真源。

- 建立 SQLite schema 和 Repository 接口。
- 实现 localStorage、IndexedDB 的可重复、可回滚迁移。
- 给实体和关系分配稳定 ID。
- IndexedDB 降级为缓存。
- 冻结 Cloudflare 默认请求路径。
- 抽离方案、日程和设置的存储逻辑。

验收：刷新、重启服务和浏览器后，方案、日程、设置数量及内容一致。

### P2：真实素材中心

目标：搜索结果能打开真实素材并解释来源。

- 接入 ExifTool。
- 建立本地文件索引、缩略图、哈希和增量扫描。
- 接入 Obsidian Local REST API，同时保留离线文件索引。
- 建立来源、授权和验证队列。
- 实现结构化筛选和 SQLite FTS。
- Pexels 作为第一个正式外部 Provider。

验收：新增笔记或图片后可以增量检索，结果能打开真实文件，重复导入不产生重复素材。

### P3：方案到复盘闭环

目标：方案能用于真实拍摄并产生反馈。

- Brief 标准化。
- 推荐槽位和关系评分。
- 镜头级参考、机位、动作、光线和替代方案。
- 从方案创建日程草稿。
- 现场勾选、备注、样片、失败和补拍。
- 复盘回流 Obsidian。
- 历史版本和局部重算。

验收：从方案到复盘的所有实体 ID 可以追踪，替换一个素材只影响关联镜头。

### P4：颜色、发布和平台导入

目标：补全后期与发布环节。

- OpenColorIO sidecar。
- LUT 档案、颜色空间和三栏预览。
- SocialPublishPackage 与 WebSeoPackage。
- 小红书/抖音辅助导入和待验证队列。
- Unsplash/Pixabay 规则化适配器。

验收：LUT 不修改原图，平台来源规则可追踪，重新打开方案能恢复 LUT 和发布包。

### P5：可选扩展

- Immich Provider。
- OpenCLIP + sqlite-vec。
- Tauri 安装包。
- 可选云同步。
- 可恢复的每日 Agent 任务。

每项必须能够关闭，并且关闭后本地核心工作流仍可用。

---

## 19. 测试与质量门

### 19.1 数据迁移

- 迁移前后各实体数量一致。
- 旧 ID 和关联关系可以追踪。
- 重复执行迁移不会重复数据。
- 中途失败能够恢复备份。

### 19.2 搜索

- 文本、标签、相机、镜头、颜色、方向和授权过滤正确。
- 文件删除、移动和修改后索引行为明确。
- 同一平台作品、URL 和文件不会重复。
- 外部服务失败时仍能使用本地数据。

### 19.3 工作流

- “城市夜景电影感人像”能得到素材、角度、姿势、光线、LUT、发布和日程关系。
- 用户锁定和否决能够持久化。
- 缺失槽位会进入 Inbox。
- 替换素材只重算受影响关系。

### 19.4 颜色

- `.cube` 文件校验失败时给出明确原因。
- 输入和输出颜色空间有记录。
- 预览和导出不覆盖原图。
- 不同强度可以恢复。

### 19.5 界面

- 六个主导航均可键盘访问。
- 桌面和 390px 手机宽度无横向溢出。
- 长标题和来源不会覆盖按钮。
- 加载、空状态、降级、失败和待验证状态完整。

### 19.6 当前测试情况

项目已经新增 Node 单元/代理测试和 Playwright E2E 脚本。此前本地记录为：

- 11 个单元及代理测试通过。
- 六个导航、关系面板、生命周期、LUT、日程和移动端溢出检查通过。

这些结果是此前运行记录，架构调整前应重新执行并建立新的基线报告。

---

## 20. 提交给 ChatGPT 的文件建议

### 必需

```text
CHATGPT-PROJECT-HANDOFF.md
package.json
index.html
src/domain.js
src/storage.js
src/app-enhancements.js
src/enhancements.css
tools/local-obsidian-proxy.js
tools/collect-platform-references.js
tools/daily-research.js
assets/agent-workflow.json
assets/workflow-database.json
assets/external-source-audit.json
tests/node/
tests/e2e/
api/index.js
wrangler.toml
README.md
```

### 视上传限制决定

```text
assets/reference-database.json
assets/open-source-reference-sources.json
assets/platform-collections.json
REFERENCE_WORKFLOW.md
DESIGN.md
DEPLOYMENT.md
```

### 不要上传

```text
node_modules/
.browser-profile/
data/platform-debug/
data/platform-captures/ 中含个人登录或页面快照的文件
assets/local-obsidian-config.json
.env
任何 API Key、Cookie、App Secret 或 JWT Secret
PhotoAtelier-Config.md
用户原图、私人 Obsidian 笔记和未授权收藏内容
```

如果 ChatGPT 无法接收整个 `index.html`，至少提供函数索引、六个页面 DOM 片段、存储键清单和所有 `src/` 文件，不能只提供截图。

---

## 21. 希望 ChatGPT 重点挑战的假设

请不要默认同意以下判断，而应给出证据和替代方案：

1. SQLite 是否应成为唯一业务数据真源？
2. 是否有必要保留 IndexedDB，还是只使用本地服务？
3. Immich 是否比自建索引更适合这个用户的数据量和 Windows 环境？
4. Obsidian Local REST API 与直接文件索引是否真的需要同时存在？
5. OpenColorIO 是否对第一版 LUT 工具过重？有没有更小但可靠的替代方案？
6. 当前 12 个主题和 262 条参考记录应如何扩充，才不会只是数量膨胀？
7. 是否应该继续 Vanilla JS 渐进拆分，还是在某个阶段切换框架？
8. Cloudflare/Supabase 应冻结、删除、重写，还是保留为同步层？
9. 飞书多维表格是必要协作出口，还是增加了重复维护？
10. 推荐评分和 Agent 质量门如何建立可量化验收？

---

## 22. ChatGPT 反馈模板

请按以下格式返回，避免只给泛泛建议。

```markdown
# PhotoAtelier 架构反馈

## 1. 总体判断
- 产品定位：
- 当前最大问题：
- 最应保留的能力：
- 最应停止继续堆叠的部分：

## 2. 同意与不同意
| 本文判断 | 同意/部分同意/不同意 | 理由 | 替代方案 |
|---|---|---|---|

## 3. 目标架构
- 数据真源：
- 前端：
- 本地服务：
- Obsidian：
- 图片/DAM：
- 云端：
- Agent：

## 4. 模块归属
| 功能 | 应放模块 | 输入 | 输出 | 依赖 | 失败降级 |
|---|---|---|---|---|---|

## 5. 外部项目决策
| 项目 | 接入/参考/拒绝 | 接入位置 | 调用方式 | 许可证与风险 | 退出方案 |
|---|---|---|---|---|---|

## 6. 数据模型修改
- 应增加实体：
- 应删除或合并实体：
- 关键关系：
- 数据迁移策略：

## 7. 数据与评测
- 当前数据是否足够：
- 最小补数方案：
- 搜索评测集：
- 推荐评测集：
- Agent 质量门：

## 8. 实施顺序
### P0
- 任务：
- 验收：
- 风险：

### P1
- 任务：
- 验收：
- 风险：

### P2 及以后
- 任务：
- 验收：
- 风险：

## 9. 不应现在做的事
- 

## 10. 需要用户决定的问题
1. 

## 11. 交回 Codex 的实施清单
| 编号 | 优先级 | 任务 | 涉及文件/模块 | 前置条件 | 验收测试 |
|---|---|---|---|---|---|
```

---

## 23. 当前 Codex 判断摘要

1. PhotoAtelier 应以“素材 -> 方案 -> 日程 -> 拍摄 -> 复盘 -> 回流”为第一主闭环。
2. 当前最大技术问题不是缺少功能，而是数据真源和模块所有权不明确。
3. `index.html` 不能继续承载新增领域逻辑，但也不应立即推倒重写。
4. Obsidian 是知识层，本地图片目录或 DAM 是媒体层，SQLite 是业务层。
5. Immich 适合作为大图库的可选 Provider，不应成为第一阶段硬依赖。
6. ExifTool、IPTC/XMP 和 OpenColorIO 比来源不明的摄影 GitHub 素材库更值得优先接入。
7. 平台收藏必须先进入待验证队列，不能直接污染正式推荐库。
8. SEO 必须拆分为社交平台发现和网站搜索引擎优化两条能力。
9. Agent 暂时保持确定性 DAG，先解决来源、数据、评测和可追踪性。
10. 正式改造前必须先建立 Git 与数据备份基线，并处理明文秘密。

以上判断不是最终决策。希望 ChatGPT 从反方、替代架构和实施成本角度进行完整复核，再把结构化反馈交回 Codex。
