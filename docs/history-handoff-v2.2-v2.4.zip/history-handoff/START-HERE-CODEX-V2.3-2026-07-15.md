# Codex 从这里开始｜PhotoAtelier V2.3

## 先读

1. `README.md`
2. `ITERATION-REPORT-V2.3.md`
3. `MARKET-RESEARCH-V2.3.md`
4. `PERSONA-USABILITY-REPORT-V2.3.md`
5. `TEST-REPORT-V2.3.md`
6. `CHANGELOG-V2.3-ITERATIVE.md`
7. `docs/ADR-001-CANONICAL-V2.md`

## 产品事实

- 根目录模块化 V2 是唯一正式产品。
- `legacy/` 是历史对照，不继续新增业务逻辑。
- `dist-v2/` 是小型正式市场发布包。
- `dist-classic-addon/` 是可选 Classic 与大型素材覆盖包。
- 角色视角只改变信息重点，不是权限系统。
- 合成场景反馈不等于真实用户访谈。

## 第一次执行

```bash
npm ci
npm run test:release
npm run test:e2e
```

当前交接环境中前两个命令通过；E2E 因沙箱浏览器策略被阻止。必须在正常浏览器或 GitHub Actions 中复跑，不要通过降低断言来绕过。

## 不可违反

- 不恢复根路径到 Classic 的自动跳转。
- 不把 Classic 和大型 LUT 重新塞回正式 `dist-v2`。
- 页面不得直接新增 `pw_*` 或 `pa_*` 业务读写。
- Agent 未经人工批准不能写正式镜头、任务和 LUT。
- 模特授权待确认或拒绝时不能开始拍摄。
- 对外角色包不得包含其他成员联系方式、内部费用和私密备注。
- 不把 Secret、原始照片或完整本地路径同步到飞书。

## P0

1. 在正常 Chrome 和移动设备上跑通完整 E2E 与离线切换。
2. 使用真实拍摄项目验证四类角色包，记录缺失和多余信息。
3. 验证飞书八表、Obsidian Bridge 和 Cloudflare 正式部署。
4. 给人员、费用、隐私和客户数据建立明确字段权限模型。

## P1

1. 镜头级参考绑定、锁定、拒绝和结果回链。
2. 设备、场地和人物的可复用资源库。
3. 生成有失效时间的只读角色分享链接。
4. 根据真实复盘趋势改进高频摩擦，而不是继续堆功能。
5. 接入外部图库、合同或支付产品，优先集成而非重写 CRM。

## 完成定义

- `npm run test:release` 通过。
- `npm run test:e2e` 在正常浏览器通过。
- 没有新增 Classic 运行时依赖。
- 新实体有稳定 `id`、`projectId`，方案子实体有 `planId`。
- 外部分享通过隐私测试。
- 变更附带验证证据和真实限制。
