# PhotoAtelier V2.4 架构蓝图｜从这里开始

## 这不是新 PRD

本蓝图基于现有 V2.3 代码、已存在的摄影工作流和用户最新确认的产品方向进行结构体检与兼容性重构规划。它不推翻现有应用，也不要求现在重做 UI。

## 当前确认的产品结构

摄影师端未来一级业务模块：

1. 方案
2. 参考库
3. 资源库：设备 / 场地 / 模特
4. 日程
5. 后期
6. 设置

总看板最后再做，它只能读取各模块状态，不成为新的业务真源。

角色结构继续保留摄影师、模特、助理三类入口，但它们不是三套重复数据：

- 摄影师拥有完整项目和方案编辑权。
- 模特只接收已确认方案生成的日程、拍摄任务、到场信息和与本人相关的内容。
- 助理只接收日程、设备物资和执行清单。
- 完整内部方案默认不直接发送给模特或助理。

## 方案生成必须调用什么

方案生成上下文必须由稳定 ID 关联以下信息：

- Project Brief
- 方案模板
- 项目选中的真实参考图
- 项目选中的设备、场地和模特
- 摄影师自己的设备库存
- 可选的“预期成片效果”请求
- 历史复盘和约束

预期成片效果分为两类，必须严格区分：

1. 真实摄影参考：来自飞书、Obsidian、个人图库或外部图库。
2. AI 概念图：用于方向表达，必须标记为 synthetic，不得伪装成实拍案例。

## 阅读顺序

1. `architecture/00-AS-IS-AUDIT.md`
2. `architecture/09-PHOTOGRAPHER-WORKFLOW-MAP.md`
3. `architecture/01-TARGET-ARCHITECTURE.md`
4. `architecture/02-DOMAIN-MODEL.md`
5. `architecture/03-APPLICATION-USE-CASES.md`
6. `architecture/04-CONTRACTS-AND-PORTS.md`
7. `architecture/05-MIGRATION-PLAN.md`
8. `architecture/06-MULTI-MODEL-TASK-PLAN.md`
9. `architecture/07-ACCEPTANCE-TEST-MATRIX.md`
10. `architecture/08-DECISION-LOG.md`

## 执行纪律

- GPT 负责变更领域模型、接口合同、状态机和任务边界。
- 执行模型不得自行新增实体、改字段含义或改变状态流。
- 不允许多个模型同时修改同一个核心文件。
- 每个任务必须先写测试，再改实现。
- UI 重做延后；当前阶段只做领域、应用服务、适配器和测试。
- V2.3 的 `npm run test:release` 必须始终保持通过。

## 第一批实现范围

只完成底层纵向链路：

```text
资源库与参考库
→ 项目选择关系
→ PlanningContextSnapshot
→ GenerationRun
→ Plan / PlanRevision / Shots
→ CalendarEvent 与预计收入
→ PostProductionJob
→ 模特与助理只读投影
```

地图、妆造专业系统、模特视觉分析 Agent、高级 LUT 市场和最终总看板不进入第一批实现。
